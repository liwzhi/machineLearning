package workDay_NavigableMap;

public class ListNode {
	long val;
	ListNode next;
//	ListNode pre;
	short id;
	ListNode(short ID,long x){
		id = ID;
		val = x;
	}
	

}
